const myUrl = "http://api.openweathermap.org/data/2.5/weather?q=Minsk,by&APPID=875012f111377f30bfe2073d73e59ee8"


let getWeather = (wUrl) => {

	return new Promise(function(resolve, reject){
		let req = new XMLHttpRequest();
		req.onload = () => {
			resolve(req.response);
		}
		req.onerror = () => {
			reject(req.statusText);
		}
		req.open("GET", wUrl, true);
		req.responseType = "json";
		req.send();
	})

	
}

// getWeather("file.json").then(function(data){
// 	console.log(data);
// }, function(err){
// 	console.log(data);
// });

let fetch = window.fetch || fetch;

fetch("file.json").then(function(data){
	return data.json()
}).then(function(json){
	console.log(json);
});






















