//// ES6

// for( var i = 0; i < 10; i++){
	
// 	(function(i){
// 			setTimeout(function(){
// 			console.log(i);
// 		}, 50);
// 	})(i);
	
// };

for( let i = 0; i < 10; i++){
	
	setTimeout(function(){
		console.log(i);
	}, 50);
	
}

// let txt = "hi";
// let txt = null;

const myText = "Hello";
//myText = null;

const myObj = {name: "Peter"};
//myObj = null;
myObj.name = "Anna";
console.log(myObj);

//// Arrow functions

let myFunc = (text, greet) => {
	console.log(greet + " " + text);
};

let textFunc = () => "Hello";
let objFunc = () => ({text: "Hello"});

console.log("TextFunc", textFunc());


let sampleObj = {
	city: "LA",
	go: function(){
		// console.log(this);
		// function innerFunc(){
		// 	console.log(this);
		// }
		// innerFunc.call(this);

		var innerArr = () => {
			console.log(this);
		}
		innerArr();	
	},
	joke: () => {
		console.log(this); /// Window
	}
}

sampleObj.go();

////// Destructuring

let arr = [1,2,3];

let [one, two, three] = arr;

let mySampleObj = {
	one: "One",
	two: "Two"
}

let {one:foo, two:bar} = sampleObj;

let myFuncOne = ({one, two}) => {
	console.log(one, two);
}

myFuncOne(mySampleObj);

////// Rest & Spread

function demoRest(firstArg, ...arr){ /// Rest
	console.log(arr);
}

demoRest("Hi", "there", "!");

let demoArr = [11,22,34, ...arr];
// let demoArr = [11,22,34].concat(arr);
// let arrCopy = [...arr];

console.log(demoArr);

/////// Classes

function User(name, city){
	//let hidden = "Secret"
	this.name = name;
	this.city = city;
	this.showInfo = function() {
		console.log(this.name);
	}
};

User.greet = function(text) {
	console.log(text);
}

// function Admin() {};
// Admin.prototype = new User("Peter", "NY");
// let adminPeter = new Admin();
// console.log(adminPeter);

function Admin(name, city) {
	User.call(this, name, city);
};
let adminAnna = new Admin("Anna", "NJ");
console.log(adminAnna);



class Es6User {
	constructor(name, city){
		this.name = name;
		this.city = city;
	}
	showInfo() {
		console.log(this.name);
	}
	static greet(text){
		console.log(text);
	}
	get showCity(){
		return "this city is " + this.city;
	}

}

class Es6Admin extends Es6User {
	constructor(name, city){
		super(name, city);
	}
}


Es6User.greet("Say hi");
let es6adm = new Es6Admin("Sarah", "NY");
console.log(es6adm);
console.log( es6adm.showCity ); 




///// Object.create

function Car(){
	this.make = "MB"
}

function MyCar(){};
MyCar.prototype = new Car();
let mb = new MyCar();

function customCreate(obj){
	function TempFunc(){};
	TempFunc.prototype = obj;
	return new TempFunc();
};

//// Generator Funcs

function* myGen(){

	yield "This";

	yield "Is my";

	return "Generator";
}

let genObj = myGen();

console.log(genObj.next());
console.log(genObj.next());
console.log(genObj.next());

// for(let value of genObj) {
// 	console.log(value);
// }

let userName = "John"
let customText = `User name is ${userName}`;
console.log(customText);

function showTemplate(){
	console.log(arguments);
}

showTemplate`Hello world! ${userName}`;

///// Default arguments


/// IN ES5
function defArg(text){
	var text = text || "Hi";
}

/// IN ES6

function defArg(text = "Hi"){
	console.log("From def arg",text);
}

defArg();

//// Collections

/// ES6 MAP

let myMap = new Map();
myMap.set("numberOne", "One");
myMap.set("numberTwo", "Two");
myMap.set("numberThree", "Three");

console.log(myMap.get("numberOne"));
console.log(myMap.has("numberOne"));

// let pseudoColl = {
// 	value: 0
// }

let mapKeys = myMap.keys();
let mapVals = myMap.values();
let mapEnt = myMap.entries();

// console.log(mapKeys);

// mapVals.forEach(function(item){
// 	console.log(item);
// })

// for(let [key, value] of myMap) {
// 	console.log(`${key} and ${value}`);
// };

for(let key of mapKeys) {
	console.log(`${key}`);
};

///// Set collection
let mySet = new Set(["Peter", "John", "Anna"]);


//// Promises

function getAnswer(callBack){
	let answer;
	setTimeout( ()=> {
		answer = "Hello from server";
		callBack(answer);
	}, 100 );
}

// getAnswer( function(data){
// 	console.log("Answer from callback: ", data);
// } );

let myPromise = new Promise(function(resolve, reject){
	setTimeout( ()=> {
		answer = "Hello from server";
		if(answer) {
			resolve(answer);
		}
		else {
			reject("Error!!")
		}
		
		
	}, 100 );
});

myPromise.then(function(data){
	console.log("Answer from promise: ", data)
}, function(err){
	console.log(err);
});























